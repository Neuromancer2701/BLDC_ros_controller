/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef ATMEL_START_H_INCLUDED
#define ATMEL_START_H_INCLUDED

#include "atmel_start_pins.h"

#ifdef __cplusplus
		extern "C" {
#endif

#include <hal_ext_irq.h>

#include "hal_usb_device.h"
#include "usbd_cdc_ser_echo.h"

	void USB_0_CLOCK_init(void);
	void USB_0_init(void);
	void USB_0_example(void);

#define CONF_DMAC_MAX_USED_DESC ( /*EIC*/ 0 + /*GCLK*/ 0 + /*SYSCTRL*/ 0 + \
	        /*PM*/ 0 + /*USB*/ 0 )

#define CONF_DMAC_MAX_USED_CH ( /*EIC*/ 0 + /*GCLK*/ 0 + /*SYSCTRL*/ 0 + \
	        /*PM*/ 0 + /*USB*/ 0 )

	/**
	 * \brief Perform system initialization, initialize pins and clocks for
	 * peripherals
	 */
	void system_init(void);

#ifdef __cplusplus
		}
#endif
#endif // ATMEL_START_H_INCLUDED
